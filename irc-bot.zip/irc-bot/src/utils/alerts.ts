export function sendAlert(message: string): void {
  console.log('ALERT:', message);
}