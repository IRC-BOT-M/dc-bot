export const settings = {
  adminRoleId: 'your-admin-role-id',
  quarantineRoleName: 'Quarantined',
  muteRoleName: 'Muted',
  alertsChannelId: 'your-alerts-channel-id',
  highPermRoles: ['Admin', 'Moderator'],
  dangerousPerms: ['ADMINISTRATOR', 'MANAGE_GUILD', 'MANAGE_ROLES'],
};